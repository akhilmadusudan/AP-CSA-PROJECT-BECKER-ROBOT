import becker.robots.*;
import java.util.Random;
import java.awt.Color;



class NewRob extends Robot
{
    NewRob(City c, int st, int ave, Direction dir, int item)
    {
        super(c, st, ave, dir, item);
    }

    public void turnRight() // Generic turnRight() method that uses the turnLeft() method 3 times to make a right turn.
    {
        this.turnLeft();
        this.turnLeft();
        this.turnLeft();
    }

    public void turnAround() // Generic turnAround() method which uses turnLeft() 2 times to make the robot turn the opposite direction.
    {
        this.turnLeft();
        this.turnLeft();
    }

    public void movetoWall() // This method allows the robot to detect if the space in front of it is clear, allowing him to move foward.
    {
        while (frontIsClear())
        {
            move();
        }
    }

    public void doEverything()
    {
        int counter;
        counter = 0;
        while (counter < 4) // A loop set up to count through how many items have been picked, then ending at 4.
        {
            this.movetoWall();
            this.pickThing();
            this.turnAround();
            this.movetoWall();
            this.turnLeft();
            this.move();
            this.turnLeft();
            counter = counter + 1; 
        }
        while (countThingsInBackpack() > 0) // This allows the robot to count the items in his Backpack and using the fuction move() to move one step and putThing() to put down one item, until the Backpack is empty at 0.
        {

            this.move();
            this.putThing();

        }

    }

    public void returnToStart()
    {
        this.turnAround();
        this.movetoWall();
        this.turnRight();
        this.movetoWall();
        this.turnRight();
        //This commands the robot to turn around, go back up, turn right then return to it's original position. 

    }

    public void DropThem()
    {
        while (!frontIsClear())
        {
            turnAround();
        }
    }

    public void dontCrash()
    {
        turnAround();
    }
}

public class A23 extends Object
{
    public static void main(String[] args)
    {
        City wallville = new City(6, 12);
        Robot rob = new Robot(wallville, 1, 2, Direction.EAST, 0);
        NewRob Karel = new NewRob(wallville, 1, 2, Direction.EAST, 0);

        A23.buildCity(wallville); // this calls the "BuildCity" method, below
        Karel.setColor(Color.BLUE);
        Karel.doEverything();
        Karel.returnToStart();
       
    }

  
    public static void buildCity(City wallville)
    {
        // Width and height must be at least 2 (each)
        // Feel free to change these numbers, and see how your race track changes

        Random randomNumberGenerator = new Random();
        int top = 1;
        int left = 2;
        int height = 4;
        int width = 4 + randomNumberGenerator.nextInt(7);

        int streetNumber = top;
        while (streetNumber <= height)
        {
            if (streetNumber == 1)
            {
                // the topmost line:
                new Wall(wallville, streetNumber, left, Direction.NORTH);
            } else if (streetNumber == height)
            {
                // generate the 'holding spot' thing at the bottom: the corner:
                new Wall(wallville, streetNumber + 1, left, Direction.WEST);
                new Wall(wallville, streetNumber + 1, left, Direction.SOUTH);
                int spotNum = left + 1;
                int counter = 0;
                while (counter < height)
                {
                    new Wall(wallville, streetNumber + 1, spotNum, Direction.NORTH);
                    new Wall(wallville, streetNumber + 1, spotNum, Direction.SOUTH);
                    // Uncomment the next line for a 'final state' picture (i.e., the second picture
                    // in the assignment)
                    // new Thing(wallville, streetNumber + 1, spotNum);
                    ++spotNum;
                    ++counter;
                }
                new Wall(wallville, streetNumber + 1, spotNum, Direction.WEST);
            }

            // the most western, vertical line:
            new Wall(wallville, streetNumber, left, Direction.WEST);
            // the most eastern, vertical line:
            new Wall(wallville, streetNumber, width, Direction.EAST);
            // the Thing at the end of the tunnel
            new Thing(wallville, streetNumber, width);

            int aveNum = left + 1;
            while (aveNum <= width)
            {
                new Wall(wallville, streetNumber, aveNum, Direction.NORTH);
                new Wall(wallville, streetNumber, aveNum, Direction.SOUTH);
                ++aveNum;
            }

            ++streetNumber;
        }
    }
}